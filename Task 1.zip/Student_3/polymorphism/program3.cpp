#include <iostream>
using namespace std;

class MediaFile {
public:
    virtual void play() {
        cout << "Playing general media" << endl;
    }
};

class AudioFile : public MediaFile {
public:
    void play() {
        cout << "Playing audio MP3 track" << endl;
    }
};

class VideoFile : public MediaFile {
public:
    void play() {
        cout << "Playing video MP4 clip" << endl;
    }
};

int main() {
    MediaFile* ptr;
    AudioFile audio;
    VideoFile video;

    ptr = &audio;
    ptr->play();

    ptr = &video;
    ptr->play();

    return 0;
}
