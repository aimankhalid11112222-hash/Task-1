#include <iostream>
using namespace std;

class Score {
public:
    int val;

    Score() {
        val = 0;
    }
    Score(int v) {
        val = v;
    }
    Score operator+(Score s) {
        Score temp;
        temp.val = val + s.val;
        return temp;
    }
    void show() {
        cout << "Score: " << val << endl;
    }
};

int main() {
    Score s1(40);
    Score s2(60);
    Score total = s1 + s2;
    total.show();
    return 0;
}
