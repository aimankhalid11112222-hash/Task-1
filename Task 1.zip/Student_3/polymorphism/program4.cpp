#include <iostream>
using namespace std;

class Courier {
public:
    virtual void deliver() {
        cout << "Standard delivery in 5 days" << endl;
    }
};

class ExpressCourier : public Courier {
public:
    void deliver() {
        cout << "Express delivery in 24 hours" << endl;
    }
};

class SameDayCourier : public Courier {
public:
    void deliver() {
        cout << "Same day delivery within 4 hours" << endl;
    }
};

int main() {
    Courier* c;
    ExpressCourier exp;
    SameDayCourier sd;

    c = &exp;
    c->deliver();

    c = &sd;
    c->deliver();

    return 0;
}
