#include <iostream>
using namespace std;

class Multiplier {
public:
    int multiply(int a, int b) {
        return a * b;
    }
    int multiply(int a, int b, int c) {
        return a * b * c;
    }
    double multiply(double a, double b) {
        return a * b;
    }
};

int main() {
    Multiplier m;
    cout << "Two ints: " << m.multiply(4, 5) << endl;
    cout << "Three ints: " << m.multiply(2, 3, 4) << endl;
    cout << "Two doubles: " << m.multiply(2.5, 4.0) << endl;
    return 0;
}
