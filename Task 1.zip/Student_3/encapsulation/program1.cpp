#include <iostream>
#include <string>
using namespace std;

class Movie {
private:
    string title;
    float rating;

public:
    void setTitle(string t) {
        title = t;
    }
    string getTitle() {
        return title;
    }
    void setRating(float r) {
        if (r >= 0.0 && r <= 10.0) {
            rating = r;
        } else {
            rating = 0.0;
        }
    }
    float getRating() {
        return rating;
    }
    void printDetails() {
        cout << "Movie: " << title << endl;
        cout << "Rating: " << rating << "/10" << endl;
    }
};

int main() {
    Movie m;
    m.setTitle("Inception");
    m.setRating(8.8);
    m.printDetails();
    return 0;
}
