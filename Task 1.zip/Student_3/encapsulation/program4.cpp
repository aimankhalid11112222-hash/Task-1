#include <iostream>
#include <string>
using namespace std;

class Account {
private:
    string ownerName;
    int rewardPoints;

public:
    void setOwner(string name) {
        ownerName = name;
        rewardPoints = 0;
    }
    void earnPoints(int pts) {
        rewardPoints = rewardPoints + pts;
    }
    int getPoints() {
        return rewardPoints;
    }
    void showProfile() {
        cout << "Owner: " << ownerName << endl;
        cout << "Points: " << rewardPoints << endl;
    }
};

int main() {
    Account acc;
    acc.setOwner("Zaid");
    acc.earnPoints(120);
    acc.showProfile();
    return 0;
}
