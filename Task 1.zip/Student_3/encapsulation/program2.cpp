#include <iostream>
#include <string>
using namespace std;

class Bike {
private:
    string model;
    int mileage;

public:
    void setModel(string m) {
        model = m;
    }
    string getModel() {
        return model;
    }
    void setMileage(int mil) {
        mileage = mil;
    }
    int getMileage() {
        return mileage;
    }
    void showBike() {
        cout << "Bike Model: " << model << endl;
        cout << "Mileage: " << mileage << " km/l" << endl;
    }
};

int main() {
    Bike b;
    b.setModel("Honda 125");
    b.setMileage(45);
    b.showBike();
    return 0;
}
