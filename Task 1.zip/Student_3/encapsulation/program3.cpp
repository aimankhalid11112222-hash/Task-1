#include <iostream>
#include <string>
using namespace std;

class Product {
private:
    int id;
    int stockQuantity;

public:
    void setId(int i) {
        id = i;
    }
    int getId() {
        return id;
    }
    void addStock(int qty) {
        stockQuantity = stockQuantity + qty;
    }
    void setStock(int s) {
        stockQuantity = s;
    }
    int getStock() {
        return stockQuantity;
    }
    void displayStock() {
        cout << "Product ID: " << id << endl;
        cout << "Available Stock: " << stockQuantity << endl;
    }
};

int main() {
    Product p;
    p.setId(102);
    p.setStock(50);
    p.addStock(25);
    p.displayStock();
    return 0;
}
