#include <iostream>
using namespace std;

class MidTerm {
public:
    int midMarks;

    void setMid(int m) {
        midMarks = m;
    }
};

class FinalTerm {
public:
    int finalMarks;

    void setFinal(int f) {
        finalMarks = f;
    }
};

class GradeSheet : public MidTerm, public FinalTerm {
public:
    void showResult() {
        cout << "Mid Term: " << midMarks << endl;
        cout << "Final Term: " << finalMarks << endl;
        cout << "Aggregate: " << midMarks + finalMarks << endl;
    }
};

int main() {
    GradeSheet gs;
    gs.setMid(35);
    gs.setFinal(55);
    gs.showResult();
    return 0;
}
