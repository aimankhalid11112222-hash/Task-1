#include <iostream>
#include <string>
using namespace std;

class Bird {
public:
    void fly() {
        cout << "Bird is flying" << endl;
    }
};

class Sparrow : public Bird {
public:
    void chirp() {
        cout << "Sparrow chirps sweetly" << endl;
    }
};

class Eagle : public Bird {
public:
    void hunt() {
        cout << "Eagle hunts from above" << endl;
    }
};

int main() {
    Sparrow s;
    s.fly();
    s.chirp();

    Eagle e;
    e.fly();
    e.hunt();
    return 0;
}
