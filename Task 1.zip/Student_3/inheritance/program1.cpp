#include <iostream>
#include <string>
using namespace std;

class Device {
public:
    string brand;

    void setBrand(string b) {
        brand = b;
    }
    void showBrand() {
        cout << "Device Brand: " << brand << endl;
    }
};

class SmartWatch : public Device {
public:
    int stepCount;

    void setWatch(string b, int steps) {
        setBrand(b);
        stepCount = steps;
    }
    void showWatch() {
        showBrand();
        cout << "Today Steps: " << stepCount << endl;
    }
};

int main() {
    SmartWatch sw;
    sw.setWatch("Apple", 8500);
    sw.showWatch();
    return 0;
}
