#include <iostream>
#include <string>
using namespace std;

class Furniture {
public:
    string material;

    void setMaterial(string m) {
        material = m;
    }
};

class Table : public Furniture {
public:
    int legs;

    void setTable(string m, int l) {
        setMaterial(m);
        legs = l;
    }
};

class DiningTable : public Table {
public:
    int seatingCapacity;

    void setDiningTable(string m, int l, int seats) {
        setTable(m, l);
        seatingCapacity = seats;
    }
    void display() {
        cout << "Material: " << material << endl;
        cout << "Legs: " << legs << endl;
        cout << "Seats: " << seatingCapacity << endl;
    }
};

int main() {
    DiningTable dt;
    dt.setDiningTable("Wood", 4, 6);
    dt.display();
    return 0;
}
