#include <iostream>
using namespace std;

class CloudStorage {
public:
    virtual void uploadFile() = 0;
};

class GoogleDrive : public CloudStorage {
public:
    void uploadFile() {
        cout << "Uploading file to Google Drive storage" << endl;
    }
};

class Dropbox : public CloudStorage {
public:
    void uploadFile() {
        cout << "Uploading file to Dropbox storage" << endl;
    }
};

int main() {
    GoogleDrive gd;
    Dropbox db;
    gd.uploadFile();
    db.uploadFile();
    return 0;
}
