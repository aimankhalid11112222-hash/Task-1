#include <iostream>
using namespace std;

class MusicPlayer {
public:
    virtual void startMusic() = 0;
};

class Spotify : public MusicPlayer {
public:
    void startMusic() {
        cout << "Streaming song on Spotify" << endl;
    }
};

class YouTubeMusic : public MusicPlayer {
public:
    void startMusic() {
        cout << "Playing music on YouTube Music" << endl;
    }
};

int main() {
    Spotify sp;
    YouTubeMusic yt;
    sp.startMusic();
    yt.startMusic();
    return 0;
}
