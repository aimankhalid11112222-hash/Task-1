#include <iostream>
using namespace std;

class GameHero {
public:
    virtual void attack() = 0;
};

class Archer : public GameHero {
public:
    void attack() {
        cout << "Archer shoots an arrow" << endl;
    }
};

class Wizard : public GameHero {
public:
    void attack() {
        cout << "Wizard casts lightning spell" << endl;
    }
};

int main() {
    Archer a;
    Wizard w;
    a.attack();
    w.attack();
    return 0;
}
