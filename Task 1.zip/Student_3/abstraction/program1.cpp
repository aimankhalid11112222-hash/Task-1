#include <iostream>
using namespace std;

class ShapeVolume {
public:
    virtual void findVolume() = 0;
};

class Cube : public ShapeVolume {
private:
    int side;

public:
    Cube(int s) {
        side = s;
    }
    void findVolume() {
        cout << "Cube Volume: " << side * side * side << endl;
    }
};

class Sphere : public ShapeVolume {
private:
    float radius;

public:
    Sphere(float r) {
        radius = r;
    }
    void findVolume() {
        cout << "Sphere Volume: " << (4.0 / 3.0) * 3.14 * radius * radius * radius << endl;
    }
};

int main() {
    Cube cb(4);
    Sphere sp(3.0);
    cb.findVolume();
    sp.findVolume();
    return 0;
}
